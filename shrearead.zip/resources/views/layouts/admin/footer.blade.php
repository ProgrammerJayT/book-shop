<footer class="footer">
  <div class="d-sm-flex justify-content-center justify-content-sm-between">
    <strong>Copyright &copy; {{date('Y')}}</strong> All rights reserved.
  </div>
</footer>